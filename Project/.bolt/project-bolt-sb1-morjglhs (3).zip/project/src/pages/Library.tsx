import React, { useState } from 'react';
import type { LibraryResource } from '../types';
import { useAuthStore } from '../store/auth';

export function Library() {
  const [resources, setResources] = useState<LibraryResource[]>([]);
  const [activeTab, setActiveTab] = useState<'gallery' | 'counselling' | 'resource' | 'other'>('gallery');
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const user = useAuthStore((state) => state.user);
  const isUltraAdmin = user?.role === 'ultra_admin';

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    const newResource: LibraryResource = {
      id: Date.now().toString(),
      title: newTitle,
      content: newContent,
      type: activeTab,
      created_by: user?.id || '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    setResources([newResource, ...resources]);
    setNewTitle('');
    setNewContent('');
  }

  const tabs = [
    { key: 'gallery', label: 'Gallery' },
    { key: 'counselling', label: 'Counselling' },
    { key: 'resource', label: 'Resource' },
    ...(isUltraAdmin ? [{ key: 'other', label: 'Other' }] : []),
  ] as const;

  const filteredResources = resources.filter(r => r.type === activeTab);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Library</h1>

      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`
                whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm
                ${activeTab === tab.key
                  ? 'border-primary text-primary'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }
              `}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>

      {(user?.role === 'ultra_admin' || (activeTab !== 'other' && user?.role === 'admin')) && (
        <div className="bg-white shadow sm:rounded-lg p-4">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                Title
              </label>
              <input
                type="text"
                id="title"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
              />
            </div>
            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-700">
                Content
              </label>
              <textarea
                id="content"
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                rows={4}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary"
              />
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                className="px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-dark transition-colors"
              >
                Add Content
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <ul className="divide-y divide-gray-200">
          {filteredResources.map((resource) => (
            <li key={resource.id} className="px-4 py-4">
              <h3 className="text-lg font-medium text-gray-900">{resource.title}</h3>
              <p className="mt-1 text-gray-600 whitespace-pre-wrap">{resource.content}</p>
              <div className="mt-2 text-sm text-gray-500">
                Added on {new Date(resource.created_at).toLocaleString()}
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}