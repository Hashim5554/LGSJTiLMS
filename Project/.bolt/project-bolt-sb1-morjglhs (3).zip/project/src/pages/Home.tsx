import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/auth';
import type { Discussion, Class, Announcement, DueWork } from '../types';
import { 
  MessageSquare,
  Calendar,
  Target,
  FileText,
  Bell,
  PlusCircle
} from 'lucide-react';

interface ContextType {
  currentClass: Class | null;
}

export function Home() {
  const [discussions, setDiscussions] = useState<Discussion[]>([]);
  const [newDiscussion, setNewDiscussion] = useState('');
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [dueWorks, setDueWorks] = useState<DueWork[]>([]);
  const [activeTab, setActiveTab] = useState<'discussions' | 'attainment' | 'due' | 'answers'>('discussions');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const user = useAuthStore((state) => state.user);
  const { currentClass } = useOutletContext<ContextType>();

  useEffect(() => {
    loadData();
  }, [currentClass]);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [announcementsData, dueWorksData] = await Promise.all([
        supabase
          .from('announcements')
          .select(`
            *,
            profiles:created_by (username)
          `)
          .eq('class_id', currentClass?.id)
          .order('created_at', { ascending: false })
          .limit(5),
        
        supabase
          .from('due_works')
          .select(`
            *,
            subjects (name),
            profiles:created_by (username)
          `)
          .eq('class_id', currentClass?.id)
          .order('due_date', { ascending: true })
      ]);

      if (announcementsData.error) throw announcementsData.error;
      if (dueWorksData.error) throw dueWorksData.error;

      setAnnouncements(announcementsData.data || []);
      setDueWorks(dueWorksData.data || []);
    } catch (error: any) {
      console.error('Error loading home data:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePostDiscussion = async () => {
    if (!newDiscussion.trim() || !user?.id || !currentClass?.id) return;

    try {
      const { data, error } = await supabase
        .from('discussions')
        .insert([{
          content: newDiscussion,
          created_by: user.id,
          class_id: currentClass.id
        }])
        .select(`
          *,
          profiles:created_by (username)
        `)
        .single();

      if (error) throw error;
      if (data) {
        setDiscussions([data, ...discussions]);
        setNewDiscussion('');
      }
    } catch (error) {
      console.error('Error posting discussion:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">{error}</p>
          <button 
            onClick={loadData}
            className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Hero Banner */}
      <div className="bg-gradient-to-br from-red-600 to-red-800 rounded-2xl shadow-2xl overflow-hidden transform transition-all duration-500 hover:scale-[1.02]">
        <div className="px-8 py-16 sm:px-12">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6 animate-fade-in">
            Welcome to LGS JTi Learning Management System
          </h1>
          <p className="text-xl text-red-100 mb-8 animate-fade-in delay-100">
            Your Learning Dashboard
          </p>
          <div className="flex flex-wrap gap-4">
            <button 
              onClick={() => setActiveTab('discussions')}
              className="inline-flex items-center px-6 py-3 bg-white text-red-600 rounded-lg font-medium hover:bg-red-50 transform transition-all duration-300 hover:scale-105 active:scale-95"
            >
              <MessageSquare className="h-5 w-5 mr-2" />
              Discussions
            </button>
            <button 
              onClick={() => setActiveTab('due')}
              className="inline-flex items-center px-6 py-3 bg-white text-red-600 rounded-lg font-medium hover:bg-red-50 transform transition-all duration-300 hover:scale-105 active:scale-95"
            >
              <Calendar className="h-5 w-5 mr-2" />
              Due Works
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Latest News */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
            <div className="px-6 py-4 border-b border-gray-100">
              <h2 className="text-xl font-semibold text-gray-800 flex items-center">
                <Bell className="h-5 w-5 mr-2 text-red-600" />
                Latest News
              </h2>
            </div>
            <div className="divide-y divide-gray-100">
              {announcements.length > 0 ? (
                announcements.map((announcement) => (
                  <div 
                    key={announcement.id} 
                    className="p-6 hover:bg-gray-50 transition-colors duration-200"
                  >
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      {announcement.title}
                    </h3>
                    <p className="text-gray-600 mb-3">{announcement.content}</p>
                    <div className="text-sm text-gray-500">
                      Posted by {announcement.profiles?.username} • {
                        new Date(announcement.created_at).toLocaleDateString()
                      }
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-6 text-center text-gray-500">
                  No announcements yet.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Due Works */}
        <div>
          <div className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
            <div className="px-6 py-4 border-b border-gray-100">
              <h2 className="text-xl font-semibold text-gray-800 flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-red-600" />
                Upcoming Due Works
              </h2>
            </div>
            <div className="divide-y divide-gray-100">
              {dueWorks.length > 0 ? (
                dueWorks.map((work) => (
                  <div 
                    key={work.id} 
                    className="p-4 hover:bg-gray-50 transition-colors duration-200"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-medium text-gray-900">{work.title}</h3>
                        <p className="text-sm text-gray-500">
                          {work.subjects?.name}
                        </p>
                      </div>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        new Date(work.due_date) < new Date()
                          ? 'bg-red-100 text-red-800'
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {new Date(work.due_date).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-6 text-center text-gray-500">
                  No due works assigned.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Discussion Section */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setActiveTab('discussions')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                activeTab === 'discussions'
                  ? 'bg-red-100 text-red-600'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <MessageSquare className="h-5 w-5" />
            </button>
            <button
              onClick={() => setActiveTab('attainment')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                activeTab === 'attainment'
                  ? 'bg-red-100 text-red-600'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Target className="h-5 w-5" />
            </button>
            <button
              onClick={() => setActiveTab('answers')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                activeTab === 'answers'
                  ? 'bg-red-100 text-red-600'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <FileText className="h-5 w-5" />
            </button>
          </div>
        </div>
        <div className="p-6">
          <div className="mb-6">
            <textarea
              value={newDiscussion}
              onChange={(e) => setNewDiscussion(e.target.value)}
              placeholder="Start a discussion..."
              className="w-full p-4 border border-gray-200 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all duration-200 resize-none"
              rows={3}
            />
            <div className="mt-2 flex justify-end">
              <button
                onClick={handlePostDiscussion}
                disabled={!newDiscussion.trim()}
                className="inline-flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50 disabled:cursor-not-allowed transform transition-all duration-200 hover:scale-105 active:scale-95"
              >
                <PlusCircle className="h-5 w-5 mr-2" />
                Post
              </button>
            </div>
          </div>
          <div className="space-y-4">
            {discussions.map((discussion) => (
              <div 
                key={discussion.id}
                className="p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200"
              >
                <p className="text-gray-800 mb-2">{discussion.content}</p>
                <div className="text-sm text-gray-500">
                  Posted by {discussion.profiles?.username} • {
                    new Date(discussion.created_at).toLocaleDateString()
                  }
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}