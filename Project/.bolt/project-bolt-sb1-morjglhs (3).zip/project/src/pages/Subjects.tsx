import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Subject } from '../types';
import { useAuthStore } from '../store/auth';
import { PlusCircle, Image, Trash2 } from 'lucide-react';

export function Subjects() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [newName, setNewName] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newImageUrl, setNewImageUrl] = useState('');
  const [showImageInput, setShowImageInput] = useState(false);
  const user = useAuthStore((state) => state.user);
  const isAdmin = user?.role === 'admin' || user?.role === 'ultra_admin';

  useEffect(() => {
    loadSubjects();
  }, []);

  async function loadSubjects() {
    const { data } = await supabase
      .from('subjects')
      .select('*')
      .order('name', { ascending: true });

    if (data) setSubjects(data);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!newName.trim() || !newDescription.trim()) return;

    const { data, error } = await supabase
      .from('subjects')
      .insert([{
        name: newName,
        description: newDescription,
        image_url: newImageUrl || null
      }])
      .select();

    if (data) {
      setSubjects([...subjects, data[0]]);
      setNewName('');
      setNewDescription('');
      setNewImageUrl('');
      setShowImageInput(false);
    }
  }

  async function handleDelete(id: string) {
    const { error } = await supabase
      .from('subjects')
      .delete()
      .eq('id', id);

    if (!error) {
      setSubjects(subjects.filter(subject => subject.id !== id));
    }
  }

  const toggleImageInput = () => {
    setShowImageInput(!showImageInput);
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Subjects</h1>

      {isAdmin && (
        <div className="bg-white shadow sm:rounded-lg p-4">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                Subject Name
              </label>
              <input
                type="text"
                id="name"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
              />
            </div>
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-gray-700">
                Description
              </label>
              <textarea
                id="description"
                value={newDescription}
                onChange={(e) => setNewDescription(e.target.value)}
                rows={3}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
              />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <label className="block text-sm font-medium text-gray-700">
                  Subject Image
                </label>
                <button
                  type="button"
                  onClick={toggleImageInput}
                  className="inline-flex items-center text-sm text-red-600 hover:text-red-700"
                >
                  <Image className="h-5 w-5 mr-1" />
                  {showImageInput ? 'Hide Image Input' : 'Add Image'}
                </button>
              </div>
              
              {showImageInput && (
                <div className="mt-2">
                  <input
                    type="url"
                    value={newImageUrl}
                    onChange={(e) => setNewImageUrl(e.target.value)}
                    placeholder="Enter image URL"
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                  />
                  <p className="mt-1 text-sm text-gray-500">
                    Enter a URL for the subject image
                  </p>
                </div>
              )}
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                className="px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 transition-colors"
              >
                <PlusCircle className="h-5 w-5 mr-2 inline" />
                Add Subject
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {subjects.map((subject) => (
          <div key={subject.id} className="relative">
            <Link
              to={`/subjects/${subject.id}`}
              className="block bg-white overflow-hidden shadow rounded-lg border border-gray-200 hover:border-red-500 transition-colors"
            >
              {subject.image_url && (
                <div className="h-40 overflow-hidden">
                  <img 
                    src={subject.image_url} 
                    alt={subject.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
              )}
              <div className="px-4 py-5 sm:p-6">
                <h3 className="text-lg font-medium text-gray-900">{subject.name}</h3>
                <p className="mt-1 text-sm text-gray-500">{subject.description}</p>
              </div>
            </Link>
            {isAdmin && (
              <button
                onClick={(e) => {
                  e.preventDefault();
                  handleDelete(subject.id);
                }}
                className="absolute top-2 right-2 p-1 bg-white rounded-full shadow-md text-red-600 hover:text-red-700"
              >
                <Trash2 className="h-5 w-5" />
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}