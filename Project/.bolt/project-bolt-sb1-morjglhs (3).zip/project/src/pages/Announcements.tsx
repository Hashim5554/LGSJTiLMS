import React, { useState, useEffect } from 'react';
import { useOutletContext } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/auth';
import type { Announcement, Class } from '../types';
import { PlusCircle, Trash2 } from 'lucide-react';
import { createNotification } from '../lib/notifications';

interface ContextType {
  currentClass: Class | null;
}

export function Announcements() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const { currentClass } = useOutletContext<ContextType>();
  const user = useAuthStore((state) => state.user);
  const isAdmin = user?.role === 'admin' || user?.role === 'ultra_admin';

  useEffect(() => {
    loadAnnouncements();
  }, [currentClass]);

  async function loadAnnouncements() {
    const { data } = await supabase
      .from('announcements')
      .select(`
        *,
        profiles:created_by (username)
      `)
      .eq('class_id', currentClass?.id)
      .order('created_at', { ascending: false });

    if (data) setAnnouncements(data);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    try {
      const { data, error } = await supabase
        .from('announcements')
        .insert([{
          title: newTitle,
          content: newContent,
          created_by: user?.id,
          class_id: currentClass?.id
        }])
        .select(`
          *,
          profiles:created_by (username)
        `)
        .single();

      if (error) throw error;
      
      if (data) {
        // Create notifications for all users in the class
        const { data: classUsers } = await supabase
          .from('class_assignments')
          .select('user_id')
          .eq('class_id', currentClass?.id);
        
        if (classUsers) {
          await Promise.all(
            classUsers.map(({ user_id }) => 
              createNotification(user_id, 'announcement', data.id)
            )
          );
        }

        setAnnouncements([data, ...announcements]);
        setNewTitle('');
        setNewContent('');
      }
    } catch (error) {
      console.error('Error creating announcement:', error);
    }
  }

  async function handleDelete(id: string) {
    const { error } = await supabase
      .from('announcements')
      .delete()
      .eq('id', id);

    if (!error) {
      setAnnouncements(announcements.filter(announcement => announcement.id !== id));
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Announcements</h1>

      {isAdmin && (
        <div className="bg-white shadow sm:rounded-lg p-4">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="title" className="block text-sm font-medium text-gray-700">
                Title
              </label>
              <input
                type="text"
                id="title"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
              />
            </div>
            <div>
              <label htmlFor="content" className="block text-sm font-medium text-gray-700">
                Content
              </label>
              <textarea
                id="content"
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                rows={4}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
              />
            </div>
            <div className="flex justify-end">
              <button
                type="submit"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
              >
                <PlusCircle className="h-5 w-5 mr-2" />
                Post Announcement
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg font-medium text-gray-900">Recent Announcements</h3>
        </div>
        <ul className="divide-y divide-gray-200">
          {announcements.map((announcement) => (
            <li key={announcement.id} className="p-4">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <h4 className="text-lg font-medium text-gray-900">{announcement.title}</h4>
                  <p className="mt-1 text-gray-600 whitespace-pre-wrap">{announcement.content}</p>
                  <div className="mt-2 text-sm text-gray-500">
                    Posted by {announcement.profiles?.username} on{' '}
                    {new Date(announcement.created_at).toLocaleString()}
                  </div>
                </div>
                {isAdmin && (
                  <button
                    onClick={() => handleDelete(announcement.id)}
                    className="ml-4 text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                )}
              </div>
            </li>
          ))}
          {announcements.length === 0 && (
            <li className="p-4 text-center text-gray-500">
              No announcements yet.
            </li>
          )}
        </ul>
      </div>
    </div>
  );
}