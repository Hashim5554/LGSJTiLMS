import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/auth';
import { supabase } from '../lib/supabase';
import type { Class } from '../types';

export function ClassSelect() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [classes, setClasses] = React.useState<Class[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    loadClasses();
  }, []);

  const loadClasses = async () => {
    setLoading(true);
    try {
      if (user?.role === 'ultra_admin') {
        // Ultra admin can see all classes
        const { data } = await supabase
          .from('classes')
          .select('*')
          .order('grade')
          .order('section');
        if (data) setClasses(data);
      } else {
        // Regular users only see assigned classes
        const { data } = await supabase
          .from('class_assignments')
          .select('classes(*)')
          .eq('user_id', user?.id);
        if (data) {
          const filteredClasses = data
            .map(d => d.classes)
            .filter(Boolean);
          setClasses(filteredClasses);
        }
      }
    } catch (error) {
      console.error('Error loading classes:', error);
    } finally {
      setLoading(false);
    }
  };

  const selectClass = (classId: string) => {
    localStorage.setItem('selectedClassId', classId);
    navigate('/');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading classes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to LGS JTi LMS</h1>
          <p className="text-xl text-gray-600">
            {user?.role === 'ultra_admin' 
              ? 'Select a class to manage'
              : 'Select your class to continue'}
          </p>
        </div>

        <div className="bg-white rounded-lg shadow overflow-hidden">
          {[3, 4, 5, 6, 7, 8].map((grade) => (
            <div key={grade} className="border-b border-gray-200 last:border-b-0">
              <div className="px-6 py-4 bg-gray-50">
                <h2 className="text-lg font-semibold text-gray-900">Grade {grade}</h2>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-6">
                {['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map((section) => {
                  const classObj = classes.find(c => c.grade === grade && c.section === section);
                  
                  // For ultra_admin, all classes should be clickable
                  const isClickable = user?.role === 'ultra_admin' || classObj !== undefined;
                  
                  return (
                    <button
                      key={`${grade}${section}`}
                      onClick={() => {
                        if (user?.role === 'ultra_admin') {
                          // For ultra_admin, find the class or create it if needed
                          const ultraAdminClass = classes.find(c => c.grade === grade && c.section === section);
                          if (ultraAdminClass) {
                            selectClass(ultraAdminClass.id);
                          } else {
                            // If class doesn't exist in the database but ultra_admin wants to access it
                            // We'll just use a temporary identifier format
                            const tempId = `grade${grade}section${section}`;
                            selectClass(tempId);
                          }
                        } else if (classObj) {
                          // For regular users, only select if class exists and is assigned
                          selectClass(classObj.id);
                        }
                      }}
                      className={`
                        p-4 rounded-lg text-center transition-colors
                        ${isClickable
                          ? 'bg-red-50 hover:bg-red-100 text-red-700 cursor-pointer'
                          : 'bg-gray-50 text-gray-400 cursor-not-allowed'
                        }
                      `}
                      disabled={!isClickable}
                    >
                      Section {section}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}