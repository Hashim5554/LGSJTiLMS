import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../store/auth';
import { supabase } from '../lib/supabase';
import { 
  Users, 
  Search, 
  Plus, 
  Check, 
  X, 
  Calendar,
  UserPlus,
  Trash2
} from 'lucide-react';

interface Club {
  id: string;
  name: string;
  description: string;
  created_at: string;
  created_by: string;
}

interface ClubMember {
  id: string;
  club_id: string;
  user_id: string;
  joined_at: string;
  profiles?: {
    id: string;
    username: string;
    photo_url: string | null;
  };
}

interface ClubAttendance {
  id: string;
  club_id: string;
  user_id: string;
  date: string;
  status: 'present' | 'absent';
  created_at: string;
  profiles?: {
    username: string;
  };
}

export function AfternoonClubs() {
  const { user } = useAuthStore();
  const [clubs, setClubs] = useState<Club[]>([]);
  const [selectedClub, setSelectedClub] = useState<string>('');
  const [clubMembers, setClubMembers] = useState<ClubMember[]>([]);
  const [attendances, setAttendances] = useState<ClubAttendance[]>([]);
  const [currentDate, setCurrentDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [newClub, setNewClub] = useState({
    name: '',
    description: ''
  });
  const [userClubs, setUserClubs] = useState<Club[]>([]);

  const isAdmin = user?.role === 'admin' || user?.role === 'ultra_admin';

  useEffect(() => {
    loadClubs();
    if (!isAdmin) {
      loadUserClubs();
    }
  }, [isAdmin, user]);

  useEffect(() => {
    if (selectedClub) {
      loadClubMembers();
      loadAttendances();
    }
  }, [selectedClub, currentDate]);

  const loadClubs = async () => {
    setLoading(true);
    try {
      const { data } = await supabase
        .from('clubs')
        .select('*')
        .order('name');
      
      if (data) setClubs(data);
    } catch (error) {
      console.error('Error loading clubs:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadUserClubs = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data } = await supabase
        .from('club_members')
        .select(`
          club_id,
          clubs (*)
        `)
        .eq('user_id', user.id);
      
      if (data) {
        const userClubsList = data.map(item => item.clubs).filter(Boolean);
        setUserClubs(userClubsList);
      }
    } catch (error) {
      console.error('Error loading user clubs:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadClubMembers = async () => {
    if (!selectedClub) return;
    
    setLoading(true);
    try {
      const { data } = await supabase
        .from('club_members')
        .select(`
          *,
          profiles:user_id (
            id,
            username,
            photo_url
          )
        `)
        .eq('club_id', selectedClub);
      
      if (data) setClubMembers(data);
    } catch (error) {
      console.error('Error loading club members:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadAttendances = async () => {
    if (!selectedClub || !currentDate) return;
    
    try {
      const { data } = await supabase
        .from('club_attendance')
        .select(`
          *,
          profiles:user_id (username)
        `)
        .eq('club_id', selectedClub)
        .eq('date', currentDate);
      
      if (data) setAttendances(data);
    } catch (error) {
      console.error('Error loading attendances:', error);
    }
  };

  const handleSearch = async () => {
    if (!searchTerm.trim()) return;
    
    setIsSearching(true);
    try {
      const { data } = await supabase
        .from('profiles')
        .select('id, username, email, photo_url')
        .ilike('username', `%${searchTerm}%`)
        .limit(10);
      
      if (data) setSearchResults(data);
    } catch (error) {
      console.error('Error searching users:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddMember = async (userId: string) => {
    if (!selectedClub) return;
    
    try {
      // Check if user is already a member
      const { data: existingMember } = await supabase
        .from('club_members')
        .select('*')
        .eq('club_id', selectedClub)
        .eq('user_id', userId)
        .single();
      
      if (existingMember) {
        setMessage({ type: 'error', text: 'User is already a member of this club' });
        return;
      }
      
      const { data, error } = await supabase
        .from('club_members')
        .insert([{
          club_id: selectedClub,
          user_id: userId
        }])
        .select(`
          *,
          profiles:user_id (
            id,
            username,
            photo_url
          )
        `)
        .single();
      
      if (error) throw error;
      
      if (data) {
        setClubMembers([...clubMembers, data]);
        setSearchResults([]);
        setSearchTerm('');
        setMessage({ type: 'success', text: 'Member added successfully' });
      }
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message });
    }
  };

  const handleRemoveMember = async (memberId: string) => {
    try {
      const { error } = await supabase
        .from('club_members')
        .delete()
        .eq('id', memberId);
      
      if (error) throw error;
      
      setClubMembers(clubMembers.filter(member => member.id !== memberId));
      setMessage({ type: 'success', text: 'Member removed successfully' });
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message });
    }
  };

  const handleAttendanceChange = async (userId: string, status: 'present' | 'absent') => {
    if (!selectedClub || !currentDate) return;
    
    try {
      // Check if attendance record already exists
      const { data: existingData } = await supabase
        .from('club_attendance')
        .select('*')
        .eq('club_id', selectedClub)
        .eq('user_id', userId)
        .eq('date', currentDate)
        .single();
      
      let data;
      
      if (existingData) {
        // Update existing record
        const { data: updatedData, error } = await supabase
          .from('club_attendance')
          .update({ status })
          .eq('id', existingData.id)
          .select(`
            *,
            profiles:user_id (username)
          `)
          .single();
        
        if (error) throw error;
        data = updatedData;
      } else {
        // Create new record
        const { data: newData, error } = await supabase
          .from('club_attendance')
          .insert([{
            club_id: selectedClub,
            user_id: userId,
            date: currentDate,
            status
          }])
          .select(`
            *,
            profiles:user_id (username)
          `)
          .single();
        
        if (error) throw error;
        data = newData;
      }
      
      if (data) {
        // Update the attendance list
        const updatedAttendances = attendances.filter(a => 
          !(a.club_id === selectedClub && a.user_id === userId && a.date === currentDate)
        );
        setAttendances([data, ...updatedAttendances]);
        setMessage({ type: 'success', text: 'Attendance updated' });
      }
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message });
    }
  };

  const handleCreateClub = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClub.name.trim()) {
      setMessage({ type: 'error', text: 'Club name is required' });
      return;
    }
    
    try {
      const { data, error } = await supabase
        .from('clubs')
        .insert([{
          name: newClub.name,
          description: newClub.description,
          created_by: user?.id
        }])
        .select()
        .single();
      
      if (error) throw error;
      
      if (data) {
        setClubs([...clubs, data]);
        setNewClub({ name: '', description: '' });
        setMessage({ type: 'success', text: 'Club created successfully' });
      }
    } catch (error: any) {
      setMessage({ type: 'error', text: error.message });
    }
  };

  // Student view component
  const StudentClubView = () => (
    <div className="space-y-6">
      {userClubs.length > 0 ? (
        userClubs.map(club => (
          <div key={club.id} className="bg-white shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
              <h3 className="text-lg leading-6 font-medium text-gray-900">{club.name}</h3>
            </div>
            <div className="border-t border-gray-200 px-4 py-5 sm:p-6">
              <p className="text-gray-600">{club.description}</p>
              
              <div className="mt-6">
                <h4 className="text-md font-medium text-gray-900">Recent Attendance</h4>
                <div className="mt-2 overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Date
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {attendances
                        .filter(a => a.club_id === club.id && a.user_id === user?.id)
                        .slice(0, 5)
                        .map((attendance) => (
                          <tr key={attendance.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {new Date(attendance.date).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                attendance.status === 'present' 
                                  ? 'bg-green-100 text-green-800' 
                                  : 'bg-red-100 text-red-800'
                              }`}>
                                {attendance.status.charAt(0).toUpperCase() + attendance.status.slice(1)}
                              </span>
                            </td>
                          </tr>
                        ))}
                      {attendances.filter(a => a.club_id === club.id && a.user_id === user?.id).length === 0 && (
                        <tr>
                          <td colSpan={2} className="px-6 py-4 text-center text-sm text-gray-500">
                            No attendance records found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        ))
      ) : (
        <div className="bg-white shadow sm:rounded-lg p-6 text-center">
          <p className="text-gray-500">You are not a member of any clubs</p>
        </div>
      )}
    </div>
  );

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Afternoon Clubs</h1>
      
      {message && (
        <div className={`p-4 rounded-md ${
          message.type === 'success' ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
        }`}>
          {message.text}
        </div>
      )}

      {isAdmin ? (
        <div className="space-y-6">
          <div className="bg-white shadow sm:rounded-lg p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Create New Club</h3>
            <form onSubmit={handleCreateClub} className="space-y-4">
              <div>
                <label htmlFor="club-name" className="block text-sm font-medium text-gray-700">
                  Club Name
                </label>
                <input
                  type="text"
                  id="club-name"
                  value={newClub.name}
                  onChange={(e) => setNewClub({...newClub, name: e.target.value})}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                  placeholder="e.g., Debate Club"
                />
              </div>
              <div>
                <label htmlFor="club-description" className="block text-sm font-medium text-gray-700">
                  Description
                </label>
                <textarea
                  id="club-description"
                  rows={3}
                  value={newClub.description}
                  onChange={(e) => setNewClub({...newClub, description: e.target.value})}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                  placeholder="Describe the club's activities and purpose"
                />
              </div>
              <div className="flex justify-end">
                <button
                  type="submit"
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
                >
                  <Plus className="h-5 w-5 mr-2" />
                  Create Club
                </button>
              </div>
            </form>
          </div>

          <div className="bg-white shadow sm:rounded-lg p-4">
            <label htmlFor="club-select" className="block text-sm font-medium text-gray-700">
              Select Club
            </label>
            <div className="mt-1 flex rounded-md shadow-sm">
              <select
                id="club-select"
                value={selectedClub}
                onChange={(e) => setSelectedClub(e.target.value)}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
              >
                <option value="">Select a club</option>
                {clubs.map(club => (
                  <option key={club.id} value={club.id}>
                    {club.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {selectedClub && (
            <>
              <div className="bg-white shadow sm:rounded-lg p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <h3 className="text-lg font-medium text-gray-900">Club Members</h3>
                  <div className="mt-2 md:mt-0 flex items-center">
                    <div className="relative flex-grow">
                      <input
                        type="text"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        placeholder="Search users by username"
                        className="block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500 pr-10"
                      />
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                        <button
                          onClick={handleSearch}
                          className="text-gray-400 hover:text-gray-500"
                        >
                          <Search className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                
                {searchResults.length > 0 && (
                  <div className="mt-2 mb-4 bg-gray-50 p-3 rounded-md">
                    <h4 className="text-sm font-medium text-gray-700 mb-2">Search Results</h4>
                    <ul className="divide-y divide-gray-200">
                      {searchResults.map(user => (
                        <li key={user.id} className="py-2 flex justify-between items-center">
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-red-600 flex items-center justify-center text-white">
                              {user.username[0].toUpperCase()}
                            </div>
                            <span className="ml-2 text-sm font-medium text-gray-900">{user.username}</span>
                          </div>
                          <button
                            onClick={() => handleAddMember(user.id)}
                            className="inline-flex items-center px-2 py-1 border border-transparent text-xs font-medium rounded text-white bg-red-600 hover:bg-red-700"
                          >
                            <UserPlus className="h-4 w-4 mr-1" />
                            Add
                          </button>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Member
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Joined
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {clubMembers.length > 0 ? (
                        clubMembers.map((member) => (
                          <tr key={member.id}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="h-8 w-8 rounded-full bg-red-600 flex items-center justify-center text-white">
                                  {member.profiles?.username[0].toUpperCase()}
                                </div>
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-gray-900">
                                    {member.profiles?.username}
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {new Date(member.joined_at).toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              <button
                                onClick={() => handleRemoveMember(member.id)}
                                className="text-red-600 hover:text-red-900"
                              >
                                <Trash2 className="h-5 w-5" />
                              </button>
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={3} className="px-6 py-4 text-center text-sm text-gray-500">
                            No members found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="bg-white shadow sm:rounded-lg p-6">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <h3 className="text-lg font-medium text-gray-900">Attendance</h3>
                  <div className="mt-2 md:mt-0 flex items-center">
                    <Calendar className="h-5 w-5 text-gray-400 mr-2" />
                    <input
                      type="date"
                      value={currentDate}
                      onChange={(e) => setCurrentDate(e.target.value)}
                      className="rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    />
                  </div>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Member
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {clubMembers.length > 0 ? (
                        clubMembers.map((member) => {
                          // Find attendance record for this member on the current date
                          const attendance = attendances.find(a => 
                            a.user_id === member.user_id && 
                            a.date === currentDate
                          );
                          
                          return (
                            <tr key={member.id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center">
                                  <div className="h-8 w-8 rounded-full bg-red-600 flex items-center justify-center text-white">
                                    {member.profiles?.username[0].toUpperCase()}
                                  </div>
                                  <div className="ml-4">
                                    <div className="text-sm font-medium text-gray-900">
                                      {member.profiles?.username}
                                    </div>
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                {attendance ? (
                                  <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                    attendance.status === 'present' 
                                      ? 'bg-green-100 text-green-800' 
                                      : 'bg-red-100 text-red-800'
                                  }`}>
                                    {attendance.status.charAt(0).toUpperCase() + attendance.status.slice(1)}
                                  </span>
                                ) : (
                                  <span className="text-gray-400">Not marked</span>
                                )}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <div className="flex space-x-2">
                                  <button
                                    onClick={() => handleAttendanceChange(member.user_id, 'present')}
                                    className={`p-1 rounded-full ${
                                      attendance?.status === 'present' 
                                        ? 'bg-green-100 text-green-600' 
                                        : 'bg-gray-100 text-gray-600 hover:bg-green-100 hover:text-green-600'
                                    }`}
                                    title="Present"
                                  >
                                    <Check className="h-5 w-5" />
                                  </button>
                                  <button
                                    onClick={() => handleAttendanceChange(member.user_id, 'absent')}
                                    className={`p-1 rounded-full ${
                                      attendance?.status === 'absent' 
                                        ? 'bg-red-100 text-red-600' 
                                        : 'bg-gray-100 text-gray-600 hover:bg-red-100 hover:text-red-600'
                                    }`}
                                    title="Absent"
                                  >
                                    <X className="h-5 w-5" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      ) : (
                        <tr>
                          <td colSpan={3} className="px-6 py-4 text-center text-sm text-gray-500">
                            No members found
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}
        </div>
      ) : (
        <StudentClubView />
      )}
    </div>
  );
}