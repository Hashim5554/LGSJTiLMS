import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/supabase';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing environment variables');
}

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

export async function signInWithEmail(email: string, password: string) {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;

    return data;
  } catch (error) {
    console.error('Sign in error:', error);
    throw error;
  }
}

export async function createUser({
  email,
  password,
  username,
  role = 'student',
}: {
  email: string;
  password: string;
  username: string;
  role?: 'ultra_admin' | 'admin' | 'student';
}) {
  try {
    // First check if username is taken
    const { data: existingUser } = await supabase
      .from('profiles')
      .select('username')
      .eq('username', username)
      .single();

    if (existingUser) {
      throw new Error('Username already taken');
    }

    // Create auth user
    const { data: authData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: {
          username,
          role,
        },
      },
    });

    if (signUpError || !authData.user) {
      throw signUpError || new Error('Failed to create user');
    }

    // Create profile
    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .insert([
        {
          id: authData.user.id,
          email,
          username,
          role,
        },
      ])
      .select()
      .single();

    if (profileError) {
      // Cleanup auth user if profile creation fails
      await supabase.auth.admin.deleteUser(authData.user.id);
      throw profileError;
    }

    return { user: authData.user, profile };
  } catch (error) {
    console.error('Create user error:', error);
    throw error;
  }
}

export async function updateUserProfile(
  userId: string,
  updates: {
    username?: string;
    photo_url?: string | null;
    role?: 'ultra_admin' | 'admin' | 'student';
  }
) {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function updateUserPassword(newPassword: string) {
  const { data, error } = await supabase.auth.updateUser({
    password: newPassword,
  });

  if (error) throw error;
  return data;
}

async function assignStudentToClass(userId: string, grade: number, section: string) {
  try {
    // Get the class ID for 7C
    const { data: classData, error: classError } = await supabase
      .from('classes')
      .select('id')
      .eq('grade', grade)
      .eq('section', section)
      .single();

    if (classError || !classData) {
      console.error('Error finding class:', classError);
      return;
    }

    // Check if assignment already exists
    const { data: existingAssignment } = await supabase
      .from('class_assignments')
      .select('id')
      .eq('user_id', userId)
      .eq('class_id', classData.id)
      .single();

    if (!existingAssignment) {
      // Create class assignment
      const { error: assignmentError } = await supabase
        .from('class_assignments')
        .insert([
          {
            user_id: userId,
            class_id: classData.id,
          },
        ]);

      if (assignmentError) {
        console.error('Error assigning to class:', assignmentError);
      }
    }
  } catch (error) {
    console.error('Error in assignStudentToClass:', error);
  }
}

// Initialize default accounts if they don't exist
export async function initializeDefaultAdmin() {
  try {
    // Create admin if it doesn't exist
    const { data: existingAdmin } = await supabase
      .from('profiles')
      .select('*')
      .eq('username', 'admin')
      .single();

    if (!existingAdmin) {
      await createUser({
        email: 'admin@lgs.edu.pk',
        password: 'admin123',
        username: 'admin',
        role: 'admin'
      });
    }

    // Create ultra admin if it doesn't exist
    const { data: existingUltraAdmin } = await supabase
      .from('profiles')
      .select('*')
      .eq('username', 'ultradmin')
      .single();

    if (!existingUltraAdmin) {
      await createUser({
        email: 'ultradmin@lgs.edu.pk',
        password: 'ultradmin1234',
        username: 'ultradmin',
        role: 'ultra_admin'
      });
    }

    // Create student if it doesn't exist
    const { data: existingStudent } = await supabase
      .from('profiles')
      .select('*')
      .eq('username', 'student')
      .single();

    if (!existingStudent) {
      const { user } = await createUser({
        email: 'student@lgs.edu.pk',
        password: 'student1234',
        username: 'student',
        role: 'student'
      });

      // Assign student to class 7C
      if (user) {
        await assignStudentToClass(user.id, 7, 'C');
      }
    }
  } catch (error) {
    console.error('Error initializing accounts:', error);
  }
}